// Import the necessary hooks from React.
import React, { useState } from 'react';
// Import the GuessRow component for displaying each guess and feedback pair.
import GuessRow from './GuessRow';

// Define the Board component which serves as the main game controller.
function Board() {
  // State to keep track of all the guesses made.
  const [guesses, setGuesses] = useState([]); //guesses is variable, setGuesses is function
  // State to keep track of feedback for each guess.
  const [feedback, setFeedback] = useState([]);
  // State for the current guess input by the user.
  const [currentGuess, setCurrentGuess] = useState('');

  // The secret code the user is trying to guess. This is static for now
  const secretCode = 'RBYG';

  // Function to generate feedback (black and white pegs) for a guess.
  const getFeedback = (guess) => {
    let blackPegs = 0; // let is to define a variable that can only be used in the block
    let whitePegs = 0;

    let secretArray = [...secretCode]; // Convert the secret code to an array for processing.
    let guessArray = [...guess]; // Convert the current guess to an array for processing.

    // Calculate black pegs (right color, right position).
    for (let i = 0; i < 4; i++) {
      if (guessArray[i] === secretArray[i]) { //strict equality
        blackPegs++;
        // Mark positions as null to indicate they've been counted.
        secretArray[i] = null; // if a match, make that index null
        guessArray[i] = null;
      }
    }

    // Calculate white pegs (right color, wrong position).
    for (let i = 0; i < 4; i++) {
      if (guessArray[i] && secretArray.includes(guessArray[i])) { //guessArray[i] can't be null
        whitePegs++;
        // Remove the matched color from secretArray to avoid counting it again.
        secretArray[secretArray.indexOf(guessArray[i])] = null;
        guessArray[i] = null;
      }
    }

    return { blackPegs, whitePegs };
  };

  // Event handler for the submit guess button.
  const handleGuessSubmit = () => {
    // Obtain feedback for the current guess.
    const feedbackForGuess = getFeedback(currentGuess);
    // Update the guesses state with the new guess.
    setGuesses(function(prevGuesses) { //function keyword is anonymous function. prevGuesses is paramater and returns new state
      return [...prevGuesses, currentGuess];
    });
    // Update the feedback state with the new feedback.
    setFeedback(prevFeedback => [...prevFeedback, feedbackForGuess]); // arrow function, prevFeedback is implicit paramater to anonymous function.
    // Reset the current guess input.
    setCurrentGuess('');
  };

  // Render the Board component.
  return (
    <div>
      <input 
        value={currentGuess} 
        onChange={e => setCurrentGuess(e.target.value)} 
        placeholder="Enter your guess (e.g., RBYG)"
      />
      <button onClick={handleGuessSubmit}>Submit Guess</button>
      
      {/* Map over the guesses and feedback state arrays to render GuessRow components */}
      <div>
        {guesses.map((guess, index) => (
          <GuessRow 
            key={index}
            guess={guess} 
            blackPegs={feedback[index].blackPegs}
            whitePegs={feedback[index].whitePegs}
          />
        ))}
      </div>
    </div>
  );
}

// Export the Board component as the default export of this module.
export default Board;