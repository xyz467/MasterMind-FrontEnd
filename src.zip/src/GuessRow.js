import React from 'react';

function GuessRow({ guess, blackPegs, whitePegs }) {
  return (
    <div>
      <span>Guess: {guess}</span>
      <span> - Black Pegs: {blackPegs}</span>
      <span> | White Pegs: {whitePegs}</span>
    </div>
  );
}

export default GuessRow;